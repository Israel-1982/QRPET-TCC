<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
    <style>
        .box-profile {
            position: relative;
            display: inline-block;
        }

        .profile-button {
            background-color: #f1f1f1;
            padding: 10px;
            cursor: pointer;
            border: none;
        }

        .dropdown-content {
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            display: none;
        }

        .box-profile:hover .dropdown-content {
            display: block;
        }

        .dropdown-item {
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-item:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
<?php
session_start();

if (isset($_SESSION['usuario_logado'])) {
    // Se o usuário estiver logado, exiba o cabeçalho para usuário logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="logado.php" class="nav-links">Início</a>
            <!-- <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">comunidade</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a> -->
        </nav>

        <div class="box-profile">
            <!-- Botão de perfil -->
            <button class="profile-button" tabindex="0">
                Meu Perfil
                <!-- Menu suspenso -->
                <div class="dropdown-content" id="myDropdown">
                    <a href="perfil.php" class="dropdown-item">Meus Perfil</a>
                    <a href="updatePets.php" class="dropdown-item">Meus Pets</a>
                    <a href="../logout.php" class="dropdown-item">Logout</a>
                </div>
            </button>
        </div>
    </header>
<?php
} else {
    // Se o usuário não estiver logado, exiba o cabeçalho para usuário não logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <!-- <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Comunidade</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a> -->
        </nav>

        <div class="box-profile">
            <!-- Botão de perfil -->
            
                <div class="box-btn-actions">
          <a href="login.php" class="btn-action">Entrar</a>
          <a href="../area-usuario/usuario/cadastro.php" class="btn-action">Cadastre-se</a>
      </div> 
                </div>
            </button>
        </div>
    </header>
<?php
}
?>

<section id="adote" class="adote-um-pet">
      <div>
        <h2>Alguns anjos não tem asas<br>têm quatro patas<strong> ADOTE. </strong></h2>
        <p>Nosso site conta com links de acesso para ONGs de adoção de animais, com isso você pode verificar se o seu pet foi acolhido por alguma ONG, ou caso queira você pode até mesmo fazer uma adoção.<br><strong>Entre em contato com uma ONG pareceira</strong></p>
       
      </div>
      <div class="box-img-main">
        <img class="img-tela3" src="../images/pets8.jpg" alt="Pets 8">
      </div>

    </section>




<section id="ampara" class="amparaong">
<div>
<p>A AMPARA é uma OSCIP sem fins lucrativos. Somos protetores de animais abandonados e vítimas de maus-tratos.
     Lutamos para que os mais de 30 milhões de animais de rua tenham uma vida com respeito e
      amor.</p>
      <a class="" href="https://amparanimal.org.br">https://amparanimal.org.br</a>
</div>
<div class="box-img-main">
<img class="" src="../images/AMPARA.png" alt="">
</div>
        </section>



        <section id="caramelo" class="carameloong">
            <div>
           <div class="p"> <p>Fundado em fevereiro de 2015, a partir da união de um grupo de pessoas em prol
                 do propósito de cuidar bem e adotar bem cada animal, o Instituto Caramelo
                  atua principalmente no resgate de animais feridos ou em situação de risco, 
                  recuperação e adoção. Mantemos um abrigo com cerca de 300 animais, entre cães 
                  e gatos, todos resgatados das ruas, onde eles são protegidos, tratados, 
                  alimentados e aguardam pela chance de serem adotados.</p></div>
        <a class="" href="https://institutocaramelo.org">https://institutocaramelo.org</a>
</div>
<div class="box-img-main">
        <img class="" src="../images/CARAMELO.png" alt="">
</div>
</section>

        


      </div>
      <div class="box-img-main">
      </section> 

        </body>
</html>