<?php
session_start();

if (isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha'])) {

include('../conexao_banco/conexao.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Use consultas preparadas para proteger contra SQL Injection
    $stmt = $conn->prepare("SELECT * FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
    $stmt->bind_param("ss", $email, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows < 1) {
        $_SESSION['mensagem'] = "Usuário não encontrado ou senha inválida.";
        header('Location: ../login.php');
    } else {
        $_SESSION['email'] = $email;
        $_SESSION['senha'] = $senha;

        header('Location: ../area-usuario/logado.php');
    }

    // Fechar a conexão com o banco de dados
    $stmt->close();
    $conn->close();
} else {
    // Lida com o caso em que o formulário não foi enviado adequadamente
    header('Location: login.php?login=erro');
}
?>

 

