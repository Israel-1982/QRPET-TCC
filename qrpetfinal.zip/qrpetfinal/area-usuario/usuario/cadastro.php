<?php
if (isset($_POST['submit'])) {
    $servidor="localhost";
	$banco="qrpet";
	$usuario="root";
	$senha="";

    // Conectar ao banco de dados
    $conn = new mysqli($servidor, $usuario, $senha, $banco);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capturar os dados do formulário e evitar SQL Injection
    $id_dono = $_POST['id_dono'];
    $nome_dono = $_POST['nome_dono'];
    $email_dono = $_POST['email_dono'];
    $tel_dono = $_POST['tel_dono'];
    $sexo_dono = $_POST['sexo_dono'];
    $senha_dono = $_POST['senha_dono'];
    $data_nascimento = $_POST['data_nascimento'];
    $resp_dono = $_POST['resp_dono'];
    $respTel_dono = $_POST['respTel_dono'];
    $confirmar_senha = $_POST['confirmar_senha'];

    // Validação dos campos
    if (empty($nome_dono) || empty($email_dono) || empty($tel_dono) || empty($sexo_dono) || empty($senha_dono) || empty($data_nascimento) || $senha_dono != $confirmar_senha) {
        echo "Por favor, preencha todos os campos corretamente.";
    } else {
        // Verificar se o email já está cadastrado
        $checkQuery = "SELECT email_dono FROM tab_dono WHERE email_dono = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("s", $email_dono);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {
            echo "O email '$email_dono' já está cadastrado.";
        } else {
            // Preparar a consulta SQL usando declarações preparadas para evitar injeção de SQL
            $insertQuery = "INSERT INTO tab_dono (id_dono, nome_dono, email_dono, sexo_dono, data_nascimento, resp_dono, respTel_dono, senha_dono, tel_dono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);

            if (!$stmt) {
                echo "Erro na preparação da consulta: " . $conn->error;
            } else {
                // Vincular os parâmetros da consulta
                $stmt->bind_param("sssssssss",$id_dono, $nome_dono, $email_dono, $sexo_dono, $data_nascimento, $resp_dono, $respTel_dono, $senha_dono, $tel_dono);

                // Executar a consulta preparada
                if ($stmt->execute()) {
                    echo "Cadastrado com sucesso";
                    header("Location: ../login.php"); // Redireciona para a página de entrada
                    exit(); // Encerra o script para evitar execução adicional
                } else {
                    echo "Erro ao cadastrar: " . $stmt->error;
                }

                // Fechar a consulta de inserção
                $stmt->close();
            }
        }

        // Fechar a consulta de verificação
        $checkStmt->close();
    }

    // Fechar a conexão com o banco
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>
<body class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="../index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
    
        <nav>
            <a href="../index.php" class="nav-links">Voltar</a>
        </nav>
    </header>
            <div class="container py-5 h-100">
              <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                  <div class="card rounded-3 text-black">
                    <div class="row g-0">
                      <div class="col-lg-6">
                        <div class="card-body p-md-5 mx-md-4">
          
                          <div class="text-center">
                            <img src="../images/logo.jpg" style="width: 185px;" alt="logo">
                            <h4 class="mt-1 mb-5 pb-1">Somos a QrPet, crie uma conta!</h4>

                          </div>
          
                          <form action = "cadastro.php" method = "POST">


                            <h5 class="mt-1 mb-5 pb-1">Crie sua conta</h5>
          
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11"> Nome e sobrenome</label>
                              <input type="text" name ="nome_dono" class="form-control"
                                placeholder="Digite seu nome e sobrenome" />
                             </div>

                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">E-mail</label>
                              <input type="email" name ="email_dono" class="form-control"
                                placeholder="E-mail..." />
                            </div>
          
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Celular</label>
                              <input type="number" name="tel_dono" class="form-control"
                              placeholder="DDD + Celular" />

                            </div>

                            <div class="form-outline mb-4">
                                <label class="form-label" name = "sexo_dono"  for="form2Example22">Sexo</label>
                                <select id="form2Example22" class="form-control" name = "sexo_dono">
                                  <option value="" disabled selected>Escolha o sexo</option>
                                  <option value="masculino">Masculino</option>
                                  <option value="feminino">Feminino</option>
                                </select>
                              </div>

                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22" >Data de nascimento</label>
                                <input type="date" name ="data_nascimento" class="form-control"
                                placeholder="Digite a data de nasc" />
                              </div>

                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11"> Nome 2º dono (OPCIONAL)</label>
                              <input type="text" name ="resp_dono" class="form-control"
                                placeholder="Digite o nome do 2º dono" />
                             </div>

                             <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Celular 2º dono (OPCIONAL)</label>
                              <input type="number" name="respTel_dono" class="form-control"
                              placeholder="DDD + Celular" />

                            </div>


                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2ExamplePassword">Senha</label>
                                <input type="password" name ="senha_dono" class="form-control"/>
                              </div>
                              
                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2ExampleConfirmPassword">Confirmação de Senha</label>
                                <input type="password" name ="confirmar_senha" class="form-control" />
                              </div>

                              <div class="text-center pt-1 mb-5 pb-1">
                                <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3"  name = "submit"  type="submit">Cadastrar</button>
                              </div>
                              

                          </form>
          <!-- div de texto-->
                        </div>
                      </div>
                      <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                        <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                          <h4 class="mb-4">Criar uma conta é rápido, fácil e gratuito.</h4>
                          <p class="small mb-0">Com a sua conta da QrPet você pode cadastrar seu Pet, adotar um pet
                            pode acompanhar as dicas!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</body>
</html>