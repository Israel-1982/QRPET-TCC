<?php
session_start(); // Iniciar a sessão
$servidor = "localhost";
$banco = "qrpet";
$usuario = "root";
$senha = "";

// Criar conexão
$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['atualizar'])) {
    $id_dono = $_POST['id'];
    $nome_dono = $_POST['nome'];
    $sexo_dono = $_POST['sexo'];
    $data_nascimento = $_POST['data_nascimento'];
    $resp_dono = $_POST['resp'];
    $respTel_dono = $_POST["respTel"];
    $senha_dono = $_POST["senha"];
    $tel_dono = $_POST["telDono"];
    $email_dono = $_POST["email"];

    // Sanitize e validar os dados
    // ... (implemente a lógica de sanitização e validação aqui)

    // Usar instrução preparada para evitar SQL Injection
    $sqlUpdate = "UPDATE tab_dono SET nome=?, sexo=?, data_nascimento=?, resp=?, respTel=?, senha=?, telDono=?, email=? WHERE id=?";
    $stmt = $conn->prepare($sqlUpdate);

    if ($stmt) {
        $stmt->bind_param("ssssssssi", $nome_dono, $sexo_dono, $data_nascimento, $resp_dono, $respTel_dono, $senha_dono, $tel_dono, $email_dono, $id_dono);

        // Executar a instrução preparada
        if ($stmt->execute()) {
            header('Location: ../logado.php');
            exit();
        } else {
            // Exibir mensagem de erro em caso de falha
            echo "Erro ao atualizar dados: " . $stmt->error;
        }

        // Fechar a instrução preparada
        $stmt->close();
    } else {
        // Exibir mensagem de erro em caso de falha na preparação
        echo "Erro na preparação da consulta: " . $conn->error;
    }
}

// Fechar a conexão
$conn->close();
?>
