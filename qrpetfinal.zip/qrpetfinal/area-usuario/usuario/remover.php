<?php
session_start();

if (isset($_SESSION['email'])) {
    $id = $_SESSION['email'];
    $senha = $_SESSION['senha'];

    // Conectar ao banco de dados
    $conn = new mysqli("localhost", "root", "", "qrpet");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Excluir o usuário do banco de dados
    $stmt = $conn->prepare("DELETE FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
    $stmt->bind_param("ss", $id, $senha);
    $stmt->execute();

    // Redirecionar para a página inicial após a exclusão
    header("Location: ../index.php");
    exit();
} else {
    // Se o usuário não estiver logado, redirecionar para a página de login
    header("Location: login.php");
    exit();
}
?>
