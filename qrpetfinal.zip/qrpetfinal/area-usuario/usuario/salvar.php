<?php
// Conectar ao banco de dados (reutilize se já não estiver conectado)
// include '../conexao_banco/conexao.php';
$servidor = "localhost";
$banco = "qrpet";
$usuario = "root";
$senha = "";

// Conectar ao banco de dados
$conn = new mysqli($servidor, $usuario, $senha, $banco);

session_start();
if (isset($_SESSION['email'])) {
  $id = $_SESSION['email'];
  $senha = $_SESSION['senha'];
}


$stmt = $conn->prepare("SELECT id_dono FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
$stmt->bind_param("ss", $id, $senha);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows >= 1) {
    $row = $result->fetch_assoc();
    $dono_id = $row['id_dono'];

    // Agora você pode usar $id_dono conforme necessário

 }

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_POST) {
    $id_dono = $_POST['id_dono'];
    $nome_dono = $_POST['nome_dono'];
    $email_dono = $_POST['email_dono'];
    $tel_dono = $_POST['tel_dono'];
    $sexo_dono = $_POST['sexo_dono'];
    $data_nascimento = $_POST['data_nascimento'];
    $resp_dono = $_POST['resp_dono'];
    $respTel_dono = $_POST['respTel_dono'];
    $senha_dono = $_POST['senha_dono'];

    // Verificar se é uma atualização ou inserção
    if (!empty($dono_id)) {
      //echo "entrou no IF $dono_id";   Atualização
        $updateQuery = "UPDATE tab_dono SET nome_dono=?, email_dono=?, tel_dono=?, sexo_dono=?, data_nascimento=?, resp_dono=?, respTel_dono=?, senha_dono=? WHERE id_dono=?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssssssssi", $nome_dono, $email_dono, $tel_dono, $sexo_dono, $data_nascimento, $resp_dono, $respTel_dono, $senha_dono, $dono_id);
    } else {
       echo "entrou no else $dono_id";
        // Inserção
        $insertQuery = "INSERT INTO tab_dono (nome_dono, email_dono, tel_dono, sexo_dono, data_nascimento, resp_dono, respTel_dono, senha_dono) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ssssssss", $nome_dono, $email_dono, $tel_dono, $sexo_dono, $data_nascimento, $resp_dono, $respTel_dono, $senha_dono);
    } 

    // Executar a consulta preparada
    if ($stmt->execute()) {
        header('Location: ../logado.php');
    } else {
        echo "Erro ao salvar dados: " . $stmt->error;
    }

    // Fechar a consulta
    $stmt->close();
} else {
    header('Location: cadastro.php?cadastro=erro');
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
