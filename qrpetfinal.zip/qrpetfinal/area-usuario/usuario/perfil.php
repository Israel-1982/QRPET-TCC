<?php
// Conectar ao banco de dados (reutilize se já não estiver conectado)
//include '../conexao_banco/conexao.php';
  $servidor="localhost";
	$banco="qrpet";
	$usuario="root";
	$senha="";

    // Conectar ao banco de dados
    $conn = new mysqli($servidor, $usuario, $senha, $banco);
    session_start();
    if (isset($_SESSION['email'])) {
      $id = $_SESSION['email'];
      $senha = $_SESSION['senha'];
    }
    
    
    $stmt = $conn->prepare("SELECT id_dono, nome_dono, sexo_dono, data_nascimento, resp_dono, 
    respTel_dono, senha_dono, tel_dono, email_dono FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
    $stmt->bind_param("ss", $id, $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    $dono = $result->fetch_assoc();

    $id_dono = $dono['id_dono'];
    $nome_dono = $dono['nome_dono'];
    $sexo_dono = $dono['sexo_dono'];
    $data_nascimento = $dono['data_nascimento'];
    $resp_dono = $dono['resp_dono'];
    $respTel_dono = $dono["respTel_dono"];
    $senha_dono = $dono["senha_dono"];
    $tel_dono = $dono["tel_dono"];
    $email_dono = $dono["email_dono"];
 

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
     
    if ($_POST){

    
    

    $id_dono = $dono['id_dono'];
    $nome_dono = $dono['nome_dono'];
    $sexo_dono = $dono['sexo_dono'];
    $data_nascimento = $dono['data_nascimento'];
    $resp_dono = $dono['resp_dono'];
    $respTel_dono = $dono["respTel_dono"];
    $senha_dono = $dono["senha_dono"];
    $tel_dono = $dono["tel_dono"];
    $email_dono = $dono["email_dono"];
    } 
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>
<body class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="../logado.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
    
        <nav>
            <a href="../logado.php" class="nav-links">Voltar</a>
        </nav>
    </header>
            <div class="container py-5 h-100">
              <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                  <div class="card rounded-3 text-black">
                    <div class="row g-0">
                      <div class="col-lg-6">
                        <div class="card-body p-md-5 mx-md-4">
          
                          <div class="text-center">
                            <img src="../images/logo.jpg"
                              style="width: 185px;" alt="logo">
                            <h4 class="mt-1 mb-5 pb-1">Aqui você pode editar o seu perfil.</h4>

                          </div>
          
                          <form method="post" action="salvar.php">


                            <h5 class="mt-1 mb-5 pb-1">Edite seu perfil.</h5>
          
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11"> Nome e sobrenome</label>
                              <input type="text" name ="nome_dono" value="<?=$nome_dono?>" class="form-control"  />
                             </div>

                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11">E-mail</label>
                              <input type="email" name ="email_dono" value="<?=$email_dono?>" class="form-control"
                                placeholder="E-mail..." />
                            </div>
          
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Celular</label>
                              <input type="number" name="tel_dono" value="<?=$tel_dono?>" class="form-control"
                              placeholder="DDD + Celular" />

                            </div>

                            <div class="form-outline mb-4">
                                <label class="form-label" name = "sexo_dono"  for="form2Example22">Sexo</label>
                                <select id="form2Example22" class="form-control" name = "sexo_dono">
                                  <option value="" disabled selected>Escolha o sexo</option>
                                  <option value="masculino">Masculino</option>
                                  <option value="feminino">Feminino</option>
                                </select>
                              </div>

                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22" >Data de nascimento</label>
                                <input type="date" name ="data_nascimento" value="<?=$data_nascimento?>" class="form-control"
                                placeholder="Digite a data de nasc" />
                              </div>

                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example11"> Nome 2º dono (OPCIONAL)</label>
                              <input type="text" name ="resp_dono" value="<?=$resp_dono?>" class="form-control"
                                placeholder="Digite o nome do 2º dono" />
                             </div>

                             <div class="form-outline mb-4">
                                <label class="form-label" for="form2Example22">Celular 2º dono (OPCIONAL)</label>
                              <input type="number" name="respTel_dono" value="<?=$respTel_dono?>" class="form-control"
                              placeholder="DDD + Celular" />

                            </div>


                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2ExamplePassword">Senha</label>
                                <input type="password" name ="senha_dono" class="form-control" />
                              </div>
                              
                              <div class="form-outline mb-4">
                                <label class="form-label" for="form2ExampleConfirmPassword">Confirmação de Senha</label>
                                <input type="password" name ="confirmar_senha" class="form-control" />
                              </div>

                              <!-- Botão de Excluir Usuário -->
                        <div class="text-end p-3">
                            <input type="hidden" id="id_dono" name="id_dono" value="<?=$id_dono?>">
                            
                            <input type="submit" class="btn btn-success" value="Salvar">
                            <a class="btn btn-danger px-3" role="button" href="remover.php">Excluir Usuário</a>
                        </div>


                          </form>
          <!-- div de texto-->
                        </div>
                      </div>
                      <!-- <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                        <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                          <h4 class="mb-4">Criar uma conta é rápido, fácil e gratuito</h4>
                          <p class="small mb-0">Com a sua conta da QrPet você pode cadastrar seu Pet, adotar um pet
                            pode acompanhar as dicas!</p> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</body>
</html>