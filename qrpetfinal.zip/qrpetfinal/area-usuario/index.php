<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
</head>
<body>

<?php
session_start();

if (isset($_SESSION['usuario_logado'])) {
    // Se o usuário estiver logado, exiba o cabeçalho para usuário logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Pets cadastrados</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a>
        </nav>

        
    </header>
<?php
} else {
    // Se o usuário não estiver logado, exiba o cabeçalho para usuário não logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Comunidade</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a>
        </nav>

       <div class="box-btn-actions">
          <a href="login.php" class="btn-action">Entrar</a>
          <a href="../area-usuario/usuario/cadastro.php" class="btn-action">Cadastre-se</a>
      </div> 
    </header>
<?php
}
?>
  <main>
    <section class="inicio">
      <div>
        <h1>Bem-vindos ao <strong>QrPet</strong></h1>
        <p>O QrPet funcionará da seguinte maneira, ao cadastrar as informações do pet e do dono, será gerado um QR Code que poderá ser impresso e colocado na coleira do animal. Se o pet se perder e alguém o encontrar, basta escanear o QR Code com o smartphone para ter acesso às informações do dono e do pet.</p>
        <a class="btn-action link-action" href="../area-usuario/usuario/cadastro.php">Ainda não tem um cadastro?</a>
        
      </div>
      <div class="box-img-main">
        <img class="img-tela1" src="../images/pets1.png" alt="Pets 1">
      </div>
    </section>

    <section class="cadastre-um-pet">
      <div class="box-img-main">
        <img class="img-tela2" src="../images/pets2.jpeg" alt="Pets 2">
      </div>
    </section>

    <section id="adote" class="adote-um-pet">
      <div>
        <h2>Alguns anjos não tem asas,<br>têm quatro patas ADOTE.</h2>
        <p>São mais de 30 milhões de animais esperando um lar cheio de afeto, respeito e amor.<br>Entre em contato com uma ONG. </p>
        <a class="btn-action link-action" href="adocao1.php">QUERO ADOTAR</a>
      </div>
      <div class="box-img-main">
        <img class="img-tela3" src="../images/pets3.jpg" alt="Pets 3">
      </div>
    </section>
    
    <section id="petscadastrados" class="pets-cadastrados">
      <div>
        <h2>Quem ama protege</h2>
        <p>Vamos construir uma comunidade de pets cadastrados, ao lado alguns já cadastrados</p>
        </div>
        <div class="box-img-main-cologem">
          <img class="img-tela4" src="../images/pets4.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets5.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets6.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets7.jpg" alt="Pets 4 com coleira">
          </div>
        </section>

    <section id="sobrenos" class="sobre-nos">
      <div>
        <h2>Somos um grupo de estudantes do<br>Centro Paula Souza</h2>
        <p>Somos alunos e pensamos nessa solução para os nossos pets, com o intuito de ajudar as pessoas e seus amados pets.<br>Vamos ajudar o maximo de pets, e de forma gratuita!
        
O site QrPet, é uma iniciativa destinada a auxiliar na localização de animais de estimação perdidos por meio de um sistema baseado em QR Code. Diante do expressivo número de animais em situação de rua no Brasil, o projeto visa oferecer uma solução tecnológica gratuita para mitigar esse problema. O site permite que os usuários cadastrem informações detalhadas sobre seus animais e, ao imprimir um QR Code, torna possível a rápida identificação e localização dos pets perdidos.
Os objetivos específicos do trabalho incluem definir o público-alvo do site, criar um sistema de cadastro e login, desenvolver uma funcionalidade de busca de animais perdidos, e integrar o site com links de ONGs que facilitam a adoção de animais.
A justificativa ressalta a abordagem gratuita do serviço, financiada por empresas terceiras através de anúncios, visando ampliar o acesso à população.
A metodologia abrangeu pesquisa de campo para compreender as necessidades dos usuários e pesquisa bibliográfica para aprimorar conhecimentos sobre as ferramentas utilizadas no desenvolvimento do sistema.
O sistema de cadastro, desenvolvido em PHP, é destacado como uma ponte digital entre cuidadores e animais de estimação, abordando tantas informações do dono quanto do pet. O QR Code é gerado utilizando a biblioteca de QrCode da Kreative Software.
A integração do site com ONGs de adoção visa oferecer aos usuários a possibilidade de verificar se seus animais foram acolhidos por alguma ONG, além de facilitar o processo de adoção. Destacam-se o Instituto Caramelo e a Ampara Animal como ONGs parceiras.
Ressalta-se a importância do QrPet como uma solução que vai além da localização, atuando como uma plataforma abrangente para o registro e gerenciamento de informações importantes sobre os animais de estimação. Destaca-se a necessidade de conscientização sobre a importância do cadastro e uso ativo do sistema para alcançar os objetivos propostos, contribuindo para a redução do número de animais perdidos e fortalecendo a conexão entre humanos e animais.
 </p>
      </div>
        <div class="box-img-main">
          <img class="img-tela5" src="../images/cps.jpg" alt="Sobre nós">
        
      </div>

    </section>
  </main>

</body>
</html>