<?php
session_start();

if (isset($_SESSION['usuario_logado'])) {
    // Se o usuário estiver logado, exiba o cabeçalho para usuário logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Pets cadastrados</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a>
        </nav>

        
    </header>
<?php
} else {
    // Se o usuário não estiver logado, exiba o cabeçalho para usuário não logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Pets cadastrados</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a>
        </nav>

       <div class="box-btn-actions">
          <a href="formulario-entrar.php" class="btn-action">Entrar</a>
          <a href="formulario-cadastrar.php" class="btn-action">Cadastre-se</a>
      </div> 
    </header>
<?php
}
?>