<?php

    $servidor = "localhost";
    $banco = "qrpet";
    $usuario = "root";
    $senha = "";

    // Conectar ao banco de dados
    $conn = new mysqli($servidor, $usuario, $senha, $banco);
    session_start();
    if (isset($_SESSION['id_pet'])) {
        $id_pet = $_SESSION['id_pet'];
    }

    if (isset($_SESSION['email'])) {
      $id = $_SESSION['email'];
      $senha = $_SESSION['senha'];
    }
    $att_pet= $_GET['id'];
    
    $stmt = $conn->prepare("SELECT id_dono FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
    $stmt->bind_param("ss", $id, $senha);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows >= 1) {
        $row = $result->fetch_assoc();
        $dono_id = $row['id_dono'];
    
        // Agora você pode usar $id_dono conforme necessário
    
     }
    
 
    $sql = "SELECT * FROM tab_pet WHERE id_dono = $dono_id ";
    $resultado = $conn->query($sql);
    
    $lista_pets = array();
    
    if ($resultado->num_rows > 0) {
        while ($row = $resultado->fetch_assoc()) {
            $lista_pets[] = $row;
        }
    }
    class Pet {
      public $id_pet;
      public $nome_pet;
      public $especie_pet;
      public $idade_pet;
      public $sexo_pet;
      public $foto_pet;
  
  
      public function __construct( $id, $nome, $especie, $idade, $sexo, $foto_pet) {
          $this->id_pet = $id;  
          $this->nome_pet = $nome;
          $this->especie_pet = $especie;
          $this->idade_pet = $idade;
          $this->sexo_pet = $sexo;
          //$this->foto_pet = $foto;
      }
  }
  
  $lista_objetos_pets = array();
  
  foreach ($lista_pets as $pet) {
      $objeto_pet = new Pet( $pet['id_pet'], $pet['nome_pet'], $pet['especie_pet'], $pet['idade_pet'], $pet['sexo_pet'], $pet['foto_pet']);
      $lista_objetos_pets[] = $objeto_pet;
  }



    $stmt = $conn->prepare("SELECT id_pet, nome_pet, raca_pet, especie_pet, idade_pet, 
    sexo_pet, foto_pet  FROM tab_pet WHERE id_pet = ? AND id_dono = ? ");
    $stmt->bind_param("ss", $id_pet, $dono_id );
  
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

    $id_pet = $_POST['id_pet'];
    $nome_pet = $_POST['nome_pet'];
    $raca_pet = 'teste';
    $especie_pet = $_POST['especie_pet'];
    $idade_pet = $_POST['idade_pet'];
    $sexo_pet = $_POST['sexo_pet'];
    $novo_nome = "";

    // Upload da foto
    if (!empty($_FILES['foto_pet']['size'])) {
        $extensao = strtolower(substr($_FILES['foto_pet']['name'], -4));
        $novo_nome = md5(time()) . $extensao;
        $diretorio = "../imgAnimal/";
        $nomeCompleto = $diretorio . $novo_nome;
        move_uploaded_file($_FILES['foto_pet']['tmp_name'], $nomeCompleto);
    }

  }
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

       if ($_POST){
   
    $id_pet             = $_POST['id_pet'];
    $nome_pet           = $_POST['nome_pet'];
    $raca_pet           = 'teste';
    $especie_pet        = $_POST['especie_pet'];
    $idade_pet          = $_POST['idade_pet'];
    $sexo_pet           = $_POST['sexo_pet'];

    // Nome da imagem
    $novo_nome = "";

    // Upload da foto
    if (!empty($_FILES['foto_pet']['size'])) {
        $extensao = strtolower(substr($_FILES['foto_pet']['name'], -4));
        $novo_nome = md5(time()) . $extensao;
        $diretorio = "../imgAnimal/";
        $nomeCompleto = $diretorio . $novo_nome;
        move_uploaded_file($_FILES['foto_pet']['tmp_name'], $nomeCompleto);
    }
  }

  ?>
    


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.0/font/bootstrap-icons.css">
</head>
<body class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="../logado.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
    
        <nav>
            <a href="../logado.php" class="nav-links">Início</a>
        </nav>
    </header>
    
        <!-- Não está sendo nessesario, estou usando uma classe dentro do body para a 
            pagina inteira ficar uma cor so <section class="h-100 gradient-form" style="background-color: #89a7b1;">-->
            <div class="container py-5 h-100">
              <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                  <div class="card rounded-3 text-black">
                    <div class="row g-0">
                      <div class="col-lg-6">
                        <div class="card-body p-md-5 mx-md-4">
          
                          <div class="text-center">
                            <img src="../images/logo.jpg"
                              style="width: 185px;" alt="logo">
                            <h4 class="mt-1 mb-5 pb-1">Agora que você tem uma conta vamos cadastar seu Pet</h4>
                          </div>
          
                









                          <form  method="post" action="salvarPet.php" enctype="multipart/form-data">
    <h5 class="mt-1 mb-5 pb-1">Editar  seu pet</h5>

    <div class="form-outline mb-4 hidden block-none" style = " display:none;">
        <label class="form-label" for="form2Example22">ID</label>
        <input type="number" name="id_pet" value="<?=$att_pet?>" id="form2Example22" class="form-control" placeholder="Codigo do pet editado" />
    </div> 

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example11">Nome</label>
        <input type="text" name="nome_pet" id="form2Example11" class="form-control" placeholder="Informe o nome do pet"  />
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Espécie do pet</label>
        <select name="especie_pet" id="form2Example22" class="form-control">
            <option value="" disabled selected>Escolha a espécie</option>
            <option value="cachorro">🐶 Cachorro</option>
            <option value="gato"> 🐱 Gato</option>
            <option value="outro"> 🐇🐥 Outro</option>
        </select>
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Idade</label>
        <input type="number" name="idade_pet" value="<?=$idade_pet?>" id="form2Example22" class="form-control" placeholder="Informe a idade" />
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Sexo</label>
        <select name="sexo_pet" id="form2Example22" class="form-control">
            <option value="" disabled selected>Escolha o sexo</option>
            <option value="macho">Macho</option>
            <option value="femea">Fêmea</option>
        </select>
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2ExamplePhoto">Foto do Pet</label>
        <input type="file" name="foto_pet" id="form2ExamplePhoto" class="form-control" accept="image/*">
    </div>

    <div class="text-end p-3">
                            <input type="hidden" id="id_dono" name="id_dono" value="<?=$id_pet?>">
                            <a class="btn btn-primary px-3" role="button" aria-disabled="true" href="../index.php">Voltar</a>
                            <input type="submit" class="btn btn-success" value="Salvar">
                            <a class="btn btn-danger px-3" role="button" href="removerPets.php">Excluir Pet</a>
                        </div>
</form>

          
                        </div>
                      </div>
                      <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                        <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                          <h4 class="mb-4">Quase lá, cadastre seu pet</h4>
                          <p class="small mb-0">Com a sua conta da QrPet você pode cadastrar seu Pet, adotar um pet
                            pode acompanhar as dicas!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</body>
</html>