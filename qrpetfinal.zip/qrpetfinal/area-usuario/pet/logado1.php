<?php
include 'qrcode.php';
session_start();

// Verifica se o formulário foi enviado
if (isset($_POST['submit'])) {
    // Conectar ao banco de dados
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'qrpet';

    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capturar os dados do formulário
    $nome_pet = $_POST['nome_pet'];
    $raca_pet = 'teste';
    $especie_pet = $_POST['especie_pet'];
    $idade_pet = $_POST['idade_pet'];
    $sexo_pet = $_POST['sexo_pet'];

    $novo_nome = "";

    // A parte de upload da foto estava fora do contexto, ajustei para que funcione
    if (!empty($_FILES['foto_pet']['size'])) {
        $extensao = strtolower(substr($_FILES['foto_pet']['name'], -4));
        $novo_nome = md5(time()) . $extensao;
        $diretorio = "imgAnimal/";
        $nomeCompleto = $diretorio . $novo_nome;
        move_uploaded_file($_FILES['foto_pet']['tmp_name'], $nomeCompleto);
    }

    // Validação dos campos
    if (empty($nome_pet) || empty($raca_pet) || empty($idade_pet) || empty($sexo_pet)) {
        echo "Por favor, preencha todos os campos corretamente.";
    } else {
        // Inserir os dados do pet
        $sqlInsertPet = "INSERT INTO tab_pet (nome_pet, especie_pet, idade_pet, sexo_pet, raca_pet, foto_pet) VALUES (?, ?, ?, ?, ?, ?)";
        $queryInsertPet = $conn->prepare($sqlInsertPet);

        if (!$queryInsertPet) {
            die("Erro na preparação da consulta de inserção: " . $conn->error);
        }

        $queryInsertPet->bind_param("sssiss", $nome_pet, $especie_pet, $idade_pet, $sexo_pet, $raca_pet, $novo_nome);
        $queryInsertPet->execute();
        $id_pet = $conn->insert_id;
        $queryInsertPet->close();

        // Gerar QR Code
       // $text = '' . $id_pet . $nome_pet . $especie_pet . $idade_pet . $sexo_pet . $novo_nome;        $name = md5(time()) . ".png";
        $text = 'http://localhost/tccfinal/tccqrpet/Attqrpet/resultado.php?id:' . $id_pet;       
         $name = md5(time()) . ".png";

        $file = "img_qrcode/" . $name;


        $options = array(
            'W' => 500,
            'H' => 500
        );

        $generator = new qrcode($text, $options);
        $image = $generator->render_image();
        imagepng($image, $file);
        imagedestroy($image);

        // Atualizar o caminho do QR Code no banco de dados
        $update_sql = "UPDATE tab_pet SET qrcode_path = ? WHERE id_pet = ?";
        $update_query = $conn->prepare($update_sql);

        if (!$update_query) {
            die("Erro na preparação da consulta de atualização: " . $conn->error);
        }

        $update_query->bind_param("si", $file, $id_pet);
        $update_query->execute();
        $update_query->close();
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
</head>
<body>
<header>
        <div class="box-img-header">
            <a href="../logado.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <!-- <a href="indexlogado.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="perfilpet.php" class="nav-links">Meus Pets Cadastrados</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a> -->
        </nav>

        <div class="box-profile">
            <!-- Botão de perfil -->
            <button class="profile-button" tabindex="0">
                Meu Perfil
                <!-- Menu suspenso -->
                <div class="dropdown-content" id="myDropdown">
                    <a href="perfilpet.php" class="dropdown-item">Meus Pets Cadastrados</a>
                    <a href="../usuario/perfil.php" class="dropdown-item">Meu Perfil</a>

                    <a href="../index.php" class="dropdown-item">Logout</a>
                </div>
            </button>
        </div>
    </header>

  <main>
    <section class="inicio">
      <div>
        <h1>Seu pet foi cadastrado ! <strong>QrPet</strong></h1>
        <p>  Seu pet foi cadastrado com sucesso! Para visualizar o QRcode clique no link abaixo </P>
        <p>e efetue o download da imagem no link abaixo:</p>

       <!-- <a class="btn-action link-action" href="perfilpet.php">Meus pets</a>
-->
<?php
echo "<style>
        p {
            font-size: 30px;
            color: #333;
        }
        a {
            text-decoration: none;
            color: #007bff;
        }
        h5 {
            font-size: 36px; /* Aumenta o tamanho da fonte para Informações do Pet Cadastrado */
            color: #555;
        }
        strong {
            font-weight: bold;
        }
        .pet-details {
            overflow: hidden; /* Limpa o fluxo para evitar problemas de layout */
        }
        .pet-details .info-container {
            float: left;
            margin-right: 20px;
            margin-left: 10px; /* Adiciona espaçamento à esquerda */
        }
        .pet-details .pet-image-container {
            float: right;
        }
        img {
            max-width: 500px;
            height: 300px; /* Adicione uma altura fixa desejada */
            border-radius: 4px;
            padding: 5px;
            vertical-align: top;
        }
        .pet-details .pet-image-container p {
            text-align: center; /* Centraliza o texto */
            font-size: 24px; /* Ajusta o tamanho da fonte do texto sobre a imagem */
            margin-top: 0; /* Remove a margem superior padrão do parágrafo */
        }
    </style>";

echo "<div class='pet-details'>";
echo "<div class='info-container'>";
echo "<p>";
echo "<br>";
echo "<a href='" . $file . "' target='_blank'>Clique aqui para visualizar o QR code do seu pet</a><br><br><br>";
echo "</p>";

// Adicione este trecho de código para exibir as informações do pet após o envio do formulário
if (isset($_POST['submit'])) {
    echo "<h5 class='mt-1 mb-5 pb-1'>Informações do Pet Cadastrado</h5><br><br><br>";
    echo "<p><strong>Nome do Pet:</strong> " . htmlspecialchars($nome_pet) . "</p>";
    echo "<p><strong>Espécie do Pet:</strong> " . htmlspecialchars($especie_pet) . "</p>";
    echo "<p><strong>Idade do Pet:</strong> " . htmlspecialchars($idade_pet) . " anos</p>";
    echo "<p><strong>Sexo do Pet:</strong> " . htmlspecialchars($sexo_pet) . "</p>";
}
echo "</div>"; // Fecha a div 'info-container'

if (!empty($novo_nome)) {
    echo "<div class='pet-image-container'><br><br><br>";
    echo "<p style='font-size: 30px;'><strong>Foto do Pet:</strong></p>"; // Ajuste o tamanho da fonte aqui
    echo "<img src='$nomeCompleto' alt='Foto do Pet'>";
    echo "</div>";
}

echo "</div>"; // Fecha a div 'pet-details'
?>


<p>   Para acessar o seu cadastro clique em  <a class="btn-action link-action" href="perfilpet.php">Meus pets</a></p>
        
      



  <style>
        .box-profile {
            position: relative;
            display: inline-block;
        }

        .profile-button {
            background-color: #f1f1f1;
            padding: 10px;
            cursor: pointer;
            border: none;
        }

        .dropdown-content {
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            display: none;
        }

        .box-profile:hover .dropdown-content {
            display: block;
        }

        .dropdown-item {
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-item:hover {
            background-color: #f1f1f1;
        }
    </style>


</body>
</html>