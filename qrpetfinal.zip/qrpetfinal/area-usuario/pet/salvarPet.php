<?php
// Conectar ao banco de dados (reutilize se já não estiver conectado)
// include '../conexao_banco/conexao.php';
$servidor = "localhost";
$banco = "qrpet";
$usuario = "root";
$senha = "";

// Conectar ao banco de dados
$conn = new mysqli($servidor, $usuario, $senha, $banco);

session_start();
    if (isset($_SESSION['id_pet'])) {
        $id_pet = $_SESSION['id_pet'];
    }

   



$stmt = $conn->prepare("SELECT id_pet FROM tab_pet WHERE id_pet = ? ");
$stmt->bind_param("s", $id_pet );
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows >= 1) {
    $row = $result->fetch_assoc();
    $pet_id = $row['id_pet'];

    // Agora você pode usar $id_dono conforme necessário

 }

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_POST) {
    $id_pet = $_POST['id_pet'];
    $nome_pet = $_POST['nome_pet'];
    $especie_pet = $_POST['especie_pet'];
    $idade_pet = $_POST['idade_pet'];
    $sexo_pet = $_POST['sexo_pet'];
    //$nomeCompleto = $_POST['foto_pet'];


    // Verificar se é uma atualização ou inserção
    if (!empty($id_pet)) {
      //echo "entrou no IF $id_pet";   
         $updateQuery = "UPDATE tab_pet SET nome_pet=?, especie_pet=?, idade_pet=?, sexo_pet=? WHERE id_pet=?";
         $stmt = $conn->prepare($updateQuery);
         $stmt->bind_param("ssssi", $nome_pet,  $especie_pet, $idade_pet, $sexo_pet, $id_pet);
    } else {
     //  echo "entrou no else $id_pet";
        // Inserção
         $insertQuery = "INSERT INTO tab_pet (nome_pet,  especie_pet, idade_pet, sexo_pet) VALUES (?, ?, ?, ?)";
         $stmt = $conn->prepare($insertQuery);
         $stmt->bind_param("ssss", $nome_pet,  $especie_pet, $idade_pet, $sexo_pet );
    
    } 

    // Executar a consulta preparada
    if ($stmt->execute()) {
       // echo "Dados salvos com sucesso!";
    } else {
       // echo "Erro ao salvar dados: " . $stmt->error;
    }

    // Fechar a consulta
    $stmt->close();
} else {
    echo "Nenhum dado enviado.";
}

// Fechar a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🐾 QR PET</title>
</head>

    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #3a415a;
        }

        h2 {
            text-align: center;
            color: #fff;
            font-size: 40px;
        }

        strong {
            color: #FFA500;
        }

        .btn-action {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            text-decoration: none;
            color: #ffff;
            background-color: #34344e;
            border-radius: 5px;
        }

        .btn-action:hover {
            background-color: var(--dark3);
   border: 1px solid var(--dark3);
        }
        .pp{
          align: center;


        }
    </style>
</head>
<body>
    <h2>Seu pet foi atualizado! <strong>(Fique atento aos dados fornecidos, você poderá sempre editá-los por aqui)</strong></h2> 
    <div class = "pp">

    <a class="btn-action link-action" href="../pet/perfilpet.php">Meus pets </a>
    </div>
</body>
</html>
``
