<?php
session_start();

if (isset($_SESSION['id_pet'])) {
    $id_pet = $_SESSION['id_pet'];

    // Conectar ao banco de dados
    $conn = new mysqli("localhost", "root", "", "qrpet");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Excluir o pet do banco de dados
    $stmt = $conn->prepare("DELETE FROM tab_pet WHERE id_pet = ?");
    $stmt->bind_param("i", $id_pet);
    $stmt->execute();

    // Redirecionar para a página inicial após a exclusão
    header("Location: ../index.php");
    exit();
} else {
    // Se o ID do pet não estiver definido, redirecionar para a página de cadastro de pets
    header("Location: ../pet/cadastroPet.php");
    exit();
}
?>
