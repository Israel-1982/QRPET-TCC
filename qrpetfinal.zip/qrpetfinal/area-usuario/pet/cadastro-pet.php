<?php
if (isset($_POST['submit'])) {
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'qrpet';

    // Conectar ao banco de dados
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capturar os dados do formulário
     echo $nome_pet = $_POST['nome_pet'];
     echo  $raca_pet = 'teste';
     echo  $especie_pet = $_POST['especie_pet'];
     echo $idade_pet = $_POST['idade_pet'];
     echo  $sexo_pet = $_POST['sexo_pet'];




           //a foto vem com a extenção $_FILES
           if(empty($_FILES['foto_pet']['size']) != 1){
            //pegar as extensão do arquivo
            $extensao = strtolower(substr($_FILES['foto_pet']['name'],-4)) ;
            $novo_nome ="";
            if ($novo_nome ==""){
                //Ciando um nome novo
                $novo_nome = md5(time()). $extensao;
            }
            //definindo o diretorio
            $diretorio = "imgAnimal/";
            //juntando o nome com o diretorio
            $nomeCompleto = $diretorio.$novo_nome;
            //efetuando o upload
            move_uploaded_file($_FILES['foto_pet']['tmp_name'], $nomeCompleto );
         }  

    // Validação dos campos
    if (empty($nome_pet) || empty($raca_pet) || empty($idade_pet) || empty($sexo_pet)) {
        echo "Por favor, preencha todos os campos corretamente.";
    } else {

        $sql = "INSERT INTO tab_pet (nome_pet, especie_pet, idade_pet, sexo_pet, raca_pet, foto_pet) VALUES
        (
            '$nome_pet',
            '$especie_pet',
            '$idade_pet',
            '$sexo_pet',
            '$raca_pet',
            '$novo_nome'
        )
        ";
    }
    $query = $conn ->prepare($sql);
    $query->execute(); 
    
}


 



// Realizamos a conexão com o banco de dados.






?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>
<body class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="../logado.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
    
        <nav>
            <a href="../logado.php" class="nav-links">Início</a>
        </nav>
    </header>
    
        <!-- Não está sendo nessesario, estou usando uma classe dentro do body para a 
            pagina inteira ficar uma cor so <section class="h-100 gradient-form" style="background-color: #89a7b1;">-->
            <div class="container py-5 h-100">
              <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                  <div class="card rounded-3 text-black">
                    <div class="row g-0">
                      <div class="col-lg-6">
                        <div class="card-body p-md-5 mx-md-4">
          
                          <div class="text-center">
                            <img src="../images/logo.jpg"
                              style="width: 185px;" alt="logo">
                            <h4 class="mt-1 mb-5 pb-1">Agora que você tem uma conta vamos cadastar seu Pet</h4>
                          </div>
          
                          <form action="./logado1.php" method="POST" enctype="multipart/form-data">
    <h5 class="mt-1 mb-5 pb-1">Cadastre seu pet</h5>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example11">Nome</label>
        <input type="text" name="nome_pet" id="form2Example11" class="form-control" placeholder="Informe o nome do pet" />
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Espécie do pet</label>
        <select name="especie_pet" id="form2Example22" class="form-control">
            <option value="" disabled selected>Escolha a espécie</option>
            <option value="cachorro">🐶 Cachorro</option>
            <option value="gato"> 🐱 Gato</option>
            <option value="outro"> 🐇🐥 Outro</option>
        </select>
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Idade</label>
        <input type="number" name="idade_pet" id="form2Example22" class="form-control" placeholder="Informe a idade" />
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Sexo</label>
        <select name="sexo_pet" id="form2Example22" class="form-control">
            <option value="" disabled selected>Escolha o sexo</option>
            <option value="macho">Macho</option>
            <option value="femea">Fêmea</option>
        </select>
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2ExamplePhoto">Foto do Pet</label>
        <input type="file" name="foto_pet" id="form2ExamplePhoto" class="form-control" accept="image/*">
    </div>

    <div class="text-center pt-1 mb-5 pb-1">
        <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3"  name="submit" type="submit">Cadastrar pet</button>
    </div>
</form>

          
                        </div>
                      </div>
                      <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                        <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                          <h4 class="mb-4">Quase lá, cadastre seu pet</h4>
                          <p class="small mb-0">Com a sua conta da QrPet você pode cadastrar seu Pet, adotar um pet
                            pode acompanhar as dicas!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</body>
</html>