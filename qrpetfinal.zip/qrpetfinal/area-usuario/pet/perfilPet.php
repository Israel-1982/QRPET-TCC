<?php
$servidor = "localhost";
$banco = "qrpet";
$usuario = "root";
$senha = "";

// Conectar ao banco de dados
$conn = new mysqli($servidor, $usuario, $senha, $banco);
session_start();

if (isset($_SESSION['id_pet'])) {
    $id_pet = $_SESSION['id_pet'];
}

if (isset($_SESSION['email'])) {
    $id = $_SESSION['email'];
    $senha = $_SESSION['senha'];
}

$stmt = $conn->prepare("SELECT id_dono FROM tab_dono WHERE email_dono = ? AND senha_dono = ?");
$stmt->bind_param("ss", $id, $senha);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows >= 1) {
    $row = $result->fetch_assoc();
    $dono_id = $row['id_dono'];
}

$sql = "SELECT * FROM tab_pet WHERE id_dono = $dono_id ";
$resultado = $conn->query($sql);

$lista_pets = array();

if ($resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        $lista_pets[] = $row;
    }
}

class Pet {
    public $id_pet;
    public $nome_pet;
    public $especie_pet;
    public $idade_pet;
    public $sexo_pet;
    public $foto_pet;

    public function __construct($id, $nome, $especie, $idade, $sexo, $foto_pet)
    {
        $this->id_pet = $id;
        $this->nome_pet = $nome;
        $this->especie_pet = $especie;
        $this->idade_pet = $idade;
        $this->sexo_pet = $sexo;
        $this->foto_pet = $foto_pet;
    }
}

$lista_objetos_pets = array();

foreach ($lista_pets as $pet) {
    $objeto_pet = new Pet($pet['id_pet'], $pet['nome_pet'], $pet['especie_pet'], $pet['idade_pet'], $pet['sexo_pet'], $pet['foto_pet']);
    $lista_objetos_pets[] = $objeto_pet;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_pet'])) {
    $id_pet_to_delete = $_POST['id_pet'];
    $stmt = $conn->prepare("DELETE FROM tab_pet WHERE id_pet = ?");
    $stmt->bind_param("i", $id_pet_to_delete);
    $stmt->execute();
    // Redirecionar para evitar reenvio do formulário
    header("Location: perfilpet.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.0/font/bootstrap-icons.css">
</head>
<body class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="../logado.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
    
        <nav>
            <a href="../logado.php" class="nav-links">Início</a>
        </nav>
    </header><br>

    <section id="petscadastrados" class="pets-cadastrados">
        <div>
            <p><h2>Edite ou remova seus pets!</h2></p>
            <p>Aqui voce pode fazer alteraçoes nos seus pets caso tenha preenchido algo errado.</p>
        </div>

        <table class="table table-striped table-dark">
            <thead>
                <tr>
                    <th>Id </th>
                    <th>Nome</th>
                    <th>Espécie</th>
                    <th>Idade</th>
                    <th>Sexo</th>
                    <th>    </th>
                    <th>    </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lista_objetos_pets as $pet) : ?>
                    <tr class="table-active">
                        <td><?php echo $pet->id_pet; ?></td>
                        <td><?php echo $pet->nome_pet; ?></td>
                        <td><?php echo $pet->especie_pet; ?></td>
                        <td><?php echo $pet->idade_pet; ?></td>
                        <td><?php echo $pet->sexo_pet; ?></td>
                        <?php echo "<td><a href='petsCadastrados.php?id=$pet->id_pet' type='button' class='btn btn-outline-warning'><i class='bi bi-pencil-square'></i></a></td>";?>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="id_pet" value="<?php echo $pet->id_pet; ?>">
                                <button type="submit" name="delete_pet" class="btn btn-outline-danger"><i class='bi bi-trash'></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</body>
</html>
