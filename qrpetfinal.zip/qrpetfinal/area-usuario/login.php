<?php
 session_start();
// Verificar se há uma mensagem de erro
if (isset($_SESSION['mensagem'])) {
  echo '<script>alert("' . $_SESSION['mensagem'] . '")</script>';
  unset($_SESSION['mensagem']); // Limpar a mensagem para que ela não seja exibida novamente
}
$erro = ""; // Variável para armazenar mensagens de erro

if (isset($_POST['submit'])) {
    $servidor="localhost";
	$banco="qrpet";
	$usuario="root";
	$senha="";

    // Conectar ao banco de dados
    $conn = new mysqli($servidor, $usuario, $senha, $banco);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capturar os dados do formulário
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verificar as credenciais no banco de dados
    $stmt = $conn->prepare("SELECT id_dono, nome_dono, email_dono, senha_dono FROM tab_dono WHERE email_dono = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id_dono, $nome_dono, $email_dono, $senha_dono);
        $stmt->fetch();
        
        // Verificar se a senha fornecida corresponde à senha no banco de dados (sem criptografia)
       if ($senha == $senha_dono) {
            // Login bem-sucedido
            
            (header("Location: ../validarUsuario.php"));
            exit(); // Encerrar o script para evitar execução adicional
        } else {
            // Senha incorreta
            $erro = "Senha incorreta. Por favor, tente novamente.";
        }
    } else {
        // Usuário não encontrado
        $erro = "Usuário não encontrado. Por favor, verifique seu email.";
    }
    
    
    $stmt->close();
    $conn->close();

  }
    // Fechar a consulta e a conexão com o banco
    
?>




<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body  class="h-100 gradient-form" style="background-color: #89a7b1;">
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>
        <div>
        <nav>
            <a href="index.php" class="nav-links">Voltar</a>
        </nav>
        </div>
    </header>

    <!-- Sua seção HTML existente aqui -->

    <!-- Exibir mensagem de erro, se houver -->
    <?php if (!empty($erro)) : ?>
        <div class="alert alert-danger text-center">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>

       <!-- Não está sendo nessesario, estou usando uma classe dentro do body para a 
            pagina inteira ficar uma cor so <section class="h-100 gradient-form" style="background-color: #89a7b1;">-->
            <div class="container py-5 h-100">
              <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                  <div class="card rounded-3 text-black">
                    <div class="row g-0">
                      <div class="col-lg-6">
                        <div class="card-body p-md-5 mx-md-4">
          <!-- div para a logo do site-->
                          <div class="text-center">
                            <img src="../images/logo.jpg"
                              style="width: 185px;" alt="logo">
                            <h4 class="mt-1 mb-5 pb-1">Somos a QrPet</h4>
                          </div>


            <!-- form para verificaçao de login.-->
                          <form action="validarUsuario.php" method="POST">
    <h5 class="mt-1 mb-5 pb-1">Por favor, entre com a sua conta</h5>
 <!-- div para acesso do ususario.-->

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example11">Login</label>
        <input type="email" name="email" id="form2Example11" class="form-control" placeholder="Digite seu email" />
    </div>

    <div class="form-outline mb-4">
        <label class="form-label" for="form2Example22">Senha</label>
        <input type="password" name="senha" id="form2Example22" class="form-control" placeholder="Digite sua senha" />
    </div>

    <div class="text-center pt-1 mb-5 pb-1">
        <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3"  name="submit" type="submit">Entrar</button>
        <a class="text-muted" href="#!  "  >  Esqueceu sua senha?</a>
    </div>

    

          <!-- div para o usuario se cadastrar-->
                        </div>
                      </div>
                      <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                        <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                            <h4 class="mb-4">Criar uma conta é rápido, fácil e gratuito.</h4>
                            <p class="small mb-0">Com a sua conta da QrPet você pode cadastrar seu Pet, adotar um pet
                              pode acompanhar as dicas!</p>
                              <br><br>

                              <div class="d-flex align-items-center justify-content-center pb-4">
        <p class="mb-0 me-2">Ainda não tem uma conta?</p>
        <a href="../area-usuario/usuario/cadastro.php" class="btn btn-outline-danger">Criar uma conta</a>
    </div>
</form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</body>
</html>