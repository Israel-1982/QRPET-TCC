<?php
include 'qrcode.php';
session_start();

// Verifica se o formulário foi enviado
if (isset($_POST['submit'])) {
    // Conectar ao banco de dados
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'qrpet';

    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capturar os dados do formulário
    $nome_pet = $_POST['nome_pet'];
    $raca_pet = 'teste';
    $especie_pet = $_POST['especie_pet'];
    $idade_pet = $_POST['idade_pet'];
    $sexo_pet = $_POST['sexo_pet'];

    $novo_nome = "";

     //a foto vem com a extenção $_FILES
     if(empty($_FILES['foto_pet']['size']) != 1){
        //pegar as extensão do arquivo
        $extensao = strtolower(substr($_FILES['foto_pet']['name'],-4)) ;
        $novo_nome ="";
        if ($novo_nome ==""){
            //Ciando um nome novo
            $novo_nome = md5(time()). $extensao;
        }
        //definindo o diretorio
        $diretorio = "imgAnimal/";
        //juntando o nome com o diretorio
        $nomeCompleto = $diretorio.$novo_nome;
        //efetuando o upload
        move_uploaded_file($_FILES['foto_pet']['tmp_name'], $nomeCompleto );
     }  

    // Validação dos campos
    if (empty($nome_pet) || empty($raca_pet) || empty($idade_pet) || empty($sexo_pet)) {
        echo "Por favor, preencha todos os campos corretamente.";
    } else {
        // Inserir os dados do pet
        $sqlInsertPet = "INSERT INTO tab_pet (nome_pet, especie_pet, idade_pet, sexo_pet, raca_pet, foto_pet) VALUES (?, ?, ?, ?, ?, ?)";
        $queryInsertPet = $conn->prepare($sqlInsertPet);

        if (!$queryInsertPet) {
            die("Erro na preparação da consulta de inserção: " . $conn->error);
        }

        $queryInsertPet->bind_param("sssiss", $nome_pet, $especie_pet, $idade_pet, $sexo_pet, $raca_pet, $novo_nome);
        $queryInsertPet->execute();
        $id_pet = $conn->insert_id;
        $queryInsertPet->close();

        // Gerar QR Code
       // $text = '' . $id_pet . $nome_pet . $especie_pet . $idade_pet . $sexo_pet . $novo_nome;        $name = md5(time()) . ".png";
        $text = 'http://localhost/tccfinal/tccqrpet/Attqrpet/resultado.php?id:' . $id_pet;       
         $name = md5(time()) . ".png";

        $file = "img_qrcode/" . $name;


        $options = array(
            'W' => 500,
            'H' => 500
        );

        $generator = new qrcode($text, $options);
        $image = $generator->render_image();
        imagepng($image, $file);
        imagedestroy($image);

        // Atualizar o caminho do QR Code no banco de dados
        $update_sql = "UPDATE tab_pet SET qrcode_path = ? WHERE id_pet = ?";
        $update_query = $conn->prepare($update_sql);

        if (!$update_query) {
            die("Erro na preparação da consulta de atualização: " . $conn->error);
        }

        $update_query->bind_param("si", $file, $id_pet);
        $update_query->execute();
        $update_query->close();
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>🐾 QR PET</title>
</head>
<body>
<header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <!-- <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Pets cadastros</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a> -->
        </nav>

        <div class="box-profile">
            <!-- Botão de perfil -->
            <button class="profile-button" tabindex="0">
                Meu Perfil
                <!-- Menu suspenso -->
                <div class="dropdown-content" id="myDropdown">
                <a href="../area-usuario/usuario/.perfil.php" class="dropdown-item">Meus Perfil</a>
                    <a href="updatePets.php" class="dropdown-item">Meus Pets</a>
                    <a href="../logout.php" class="dropdown-item">Logout</a>
                </div>
            </button>
        </div>
    </header>
<?php
{} else {
    // Se o usuário não estiver logado, exiba o cabeçalho para usuário não logado
?>
    <header>
        <div class="box-img-header">
            <a href="index.php">
                <img class="img-logo" src="../images/logo.jpg" alt="Logo QrPet">
            </a>
        </div>

        <nav>
            <a href="index.php" class="nav-links">Início</a>
            <a href="#adote" class="nav-links">Adote um Pet</a>
            <a href="#petscadastrados" class="nav-links">Pets cadastrados</a>
            <a href="#sobrenos" class="nav-links">Sobre nós</a>
        </nav>

        <div class="box-profile">
            <!-- Botão de perfil -->
            <button class="profile-button" tabindex="0">
                Meu Perfil
                <!-- Menu suspenso -->
                <div class="dropdown-content" id="myDropdown">
                <a href="../area-usuario/usuario/perfil.php" class="dropdown-item">Meus Perfil</a>
                    <a href="../area-usuario/pet/perfilPet.php" class="dropdown-item">Meus Pets</a>
                    <a href="../logout.php" class="dropdown-item">Logout</a>
                </div>
            </button>
        </div>
    </header>
<?php
}
?>


  <main>
    <section class="inicio">
      <div>
        <h1>Bem vindos ao <strong>QrPet</strong></h1>
        <p>O QrPet funcionará da seguinte maneira ao cadastrar as informações do pet e do dono, será gerado um QR Code que poderá ser impresso e colocado na coleira do animal. Se o pet se perder e alguém o encontrar, basta escanear o QR Code com o smartphone para ter acesso às informações do dono e do pet. Além disso iremos trabalhar em conjunto com a ONG, para conseguirmos lar, para os pets que precisam do seu amor e carinho!</p>
        <a class="btn-action link-action" href="../area-usuario/pet/cadastro-pet.php">Cadastre seu pet</a>
      </div>
      <div class="box-img-main">
        <img class="img-tela1" src="../images/pets1.png" alt="Pets 1">
      </div>
    </section>

    <section class="cadastre-um-pet">
      <div class="box-img-main">
        <img class="img-tela2" src="../images/pets2.jpeg" alt="Pets 2">
      </div>
    </section>

    <section id="adote" class="adote-um-pet">
      <div>
        <h2>Alguns anjos não tem asas<br>têm quatro patas ADOTE</h2>
        <p>São mais de 30 milhões de animais esperando um lar cheio de afeto, respeito e amor.<br><strong>Entre em contato com uma ONG pareceira</strong></p>
        <a class="btn-action link-action" href="#adote">QUERO ADOTAR</a>
      </div>
      <div class="box-img-main">
        <img class="img-tela3" src="../images/pets3.jpg" alt="Pets 3">
      </div>
    </section>
    
    <section id="petscadastrados" class="pets-cadastrados">
      <div>
        <h2>Quem ama protege</h2>
        <p>Vamos construir uma comunidade de pets cadastrados, ao lado alguns já cadastrados</p>
        </div>
        <div class="box-img-main-cologem">
          <img class="img-tela4" src="../images/pets4.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets4.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets4.jpg" alt="Pets 4 com coleira">
          <img class="img-tela4" src="../images/pets4.jpg" alt="Pets 4 com coleira">
          </div>
        </section>

    <section id="sobrenos" class="sobre-nos">
      <div>
        <h2>Somos um grupo de estudantes do<br>Centro Paula Souza</h2>
        <p>Somos alunos e pensamos nessa solução para os nossos pets, com o intuito de ajudar as pessoas e seus amados pets.<br>Vamos ajudar o maximo de pets, e de forma gratuita!!!</p>
      </div>
        <div class="box-img-main">
          <img class="img-tela5" src="../images/cps.jpg" alt="Sobre nós">
        
      </div>

    </section>
  </main>


  <script>
    function toggleDropdown() {
        var dropdown = document.getElementById("myDropdown");
        dropdown.classList.toggle("show");
    }
</script>
</body>
</html>