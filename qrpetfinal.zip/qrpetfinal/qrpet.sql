-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Dez-2023 às 01:53
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qrpet`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tab_dono`
--

CREATE TABLE `tab_dono` (
  `id_dono` int(11) NOT NULL,
  `nome_dono` varchar(45) NOT NULL,
  `email_dono` varchar(110) NOT NULL,
  `sexo_dono` varchar(15) NOT NULL,
  `data_nascimento` date NOT NULL,
  `senha_dono` varchar(30) NOT NULL,
  `tel_dono` varchar(15) NOT NULL,
  `resp_dono` varchar(60) DEFAULT NULL,
  `respTel_dono` int(17) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tab_dono`
--

INSERT INTO `tab_dono` (`id_dono`, `nome_dono`, `email_dono`, `sexo_dono`, `data_nascimento`, `senha_dono`, `tel_dono`, `resp_dono`, `respTel_dono`) VALUES
(1, 'felipe', 'felipe@husauhasuh', 'masculino', '1010-10-10', '123', '488748948949', NULL, NULL),
(2, 'israel', 'israel@g', 'masculino', '0000-00-00', '123', '4949949494', NULL, NULL),
(3, 'fe', 'fe@f', 'masculino', '1999-01-12', '123', '894848849', NULL, NULL),
(4, 'll', 'll@g', 'masculino', '1999-12-12', '123', '7887879789789', NULL, NULL),
(5, 'fafa', 'fafa@fafa', 'masculino', '2541-12-12', '123', '8987897789789', NULL, NULL),
(6, 'fa', 'fa@fa', 'masculino', '1111-12-12', '123', '7979797979', '', 0),
(7, 'Felipe Souza', 'felipe1@gmai.com', 'masculino', '1993-10-12', '123', '11949821600', 'Angela', 2147483647),
(8, 'ja', 'ja@gmail.com', 'masculino', '1000-10-10', '123', '1111111111', '', 0),
(9, 'a', 'a@gmail.com', 'masculino', '1212-05-12', '123', '949449949494949', 'kk', 2147483647);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tab_pet`
--

CREATE TABLE `tab_pet` (
  `id_pet` int(11) NOT NULL,
  `nome_pet` varchar(30) NOT NULL,
  `especie_pet` varchar(20) NOT NULL,
  `idade_pet` int(2) NOT NULL,
  `sexo_pet` varchar(10) NOT NULL,
  `raca_pet` varchar(35) NOT NULL,
  `foto_pet` varchar(100) NOT NULL,
  `id_dono` int(11) NOT NULL,
  `qrcode_path` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tab_pet`
--

INSERT INTO `tab_pet` (`id_pet`, `nome_pet`, `especie_pet`, `idade_pet`, `sexo_pet`, `raca_pet`, `foto_pet`, `id_dono`, `qrcode_path`) VALUES
(1, 'Laila', 'cachorro', 0, 'femea', '0', '0', 1, ''),
(2, 'Laila', 'cachorro', 13, 'femea', '0', '', 9, ''),
(3, 'negao', 'cachorro', 14, 'macho', '0', '', 9, ''),
(4, 'caramelo', 'cachorro', 1, 'macho', 'caramelo', 'tiamat.jpg', 9, ''),
(5, 'caramelo', 'cachorro', 1, 'macho', 'caramelo', 'tiamat.jpg', 9, ''),
(6, 'vira lata5555', 'teste', 0, '5', 'macho', 'c39d22b34e829e3adace7a4872471ff7.png', 9, ''),
(7, 'vira lata', 'teste', 0, '6', 'macho', 'ecaa3aa2682bf5b13c27225a472ed9f7.png', 2, ''),
(8, 'vira lata', 'cachorro', 6, 'macho', 'teste', 'bcd7abd59e010a8c4623a59eac472736.png', 9, ''),
(9, 'vira lata 66666', 'cachorro', 5, 'macho', 'teste', 'c82dee9392d4426266f0cb283c47b7f4.png', 9, ''),
(10, 'teste', 'cachorro', 4555, 'macho', 'teste', '7c93bfdeb4c90f92c8120d549961bf69.png', 9, ''),
(11, 'teste', 'outro', 4, 'macho', 'teste', 'ce74cc47e8d95988a6bd9d3d942e90e6.png', 9, ''),
(12, 'ttt', 'outro', 6, 'femea', 'teste', '372d316ecf816af7eeac869244af4a18.png', 9, ''),
(13, 'ttt', 'outro', 6, 'femea', 'teste', '230c35dee60c53127bcfc5f0c3e9af82.png', 9, ''),
(14, 'teste', 'cachorro', 11, 'macho', 'teste', 'd764a4d199606ab25660d4e4bc0b3262.png', 9, ''),
(15, 'bbbb', 'cachorro', 7, 'macho', 'teste', 'a9931a4c9af680f90969266ccbb99839.png', 9, ''),
(16, 'tttjjj', 'gato', 1, 'femea', 'teste', '16c176c705a28685b4322247778baf00.png', 9, ''),
(17, 'wdw', 'gato', 2, 'macho', 'teste', 'c50292bd55392a798a7f0a48bc6992f1.png', 9, ''),
(18, 'wdw', 'gato', 2, 'macho', 'teste', 'e5f4b4f36dc6e394390296482aae3106.png', 9, ''),
(19, 'wdw', 'gato', 2, 'macho', 'teste', 'e0473b40a4eaacc105eee2d6a8a33a34.png', 9, ''),
(20, 'fabio', 'outro', 465, '0', 'teste', 'eece8d2ebab7ff88336d62773ff908e6.jpg', 9, ''),
(21, 'fabio', 'outro', 465, '0', 'teste', '8b8db1bbfda32957a592cb3086090546.jpg', 0, 'img_qrcode/8b8db1bbfda32957a592cb3086090546.png'),
(22, 'fabio', 'gato', 3, '0', 'teste', 'e1308e0a203f3cd4cb388f2e89d7f76f.jpg', 0, 'img_qrcode/e1308e0a203f3cd4cb388f2e89d7f76f.png'),
(23, 'fabio', 'gato', 3, '0', 'teste', 'be92e9cbb475121ab16e7e4b951a2baa.jpg', 0, 'img_qrcode/347850b891030934ee41b6e10f86aa4f.png'),
(24, 'fabio', 'gato', 3, '0', 'teste', '3df108947b388a13ca6e7a2385bf20d8.jpg', 0, 'img_qrcode/3df108947b388a13ca6e7a2385bf20d8.png'),
(25, 'fabio', 'gato', 3, '0', 'teste', '7647ff46c430b8fcd201d0ba60070951.jpg', 0, 'img_qrcode/7647ff46c430b8fcd201d0ba60070951.png'),
(26, 'fabio', 'gato', 3, '0', 'teste', '2f1a24a4aab3459f07c2266e16a1310c.jpg', 0, 'img_qrcode/2f1a24a4aab3459f07c2266e16a1310c.png'),
(27, 'fabio', 'gato', 3, '0', 'teste', 'eff8e68fc538f6c009df39de44d57bad.jpg', 0, 'img_qrcode/eff8e68fc538f6c009df39de44d57bad.png'),
(28, 'fabio', 'gato', 3, '0', 'teste', 'b616ae86d9a17eff01a0bdb810911d7b.jpg', 0, 'img_qrcode/b616ae86d9a17eff01a0bdb810911d7b.png'),
(29, 'fabio', 'gato', 3, '0', 'teste', 'a6f0663a8fcf7cd14437862578a3245c.jpg', 0, 'img_qrcode/a6f0663a8fcf7cd14437862578a3245c.png'),
(30, 'fabio', 'cachorro', 34, '0', 'teste', 'f19508a6ca41605dbd555337e247aea0.jpg', 0, 'img_qrcode/f19508a6ca41605dbd555337e247aea0.png'),
(31, 'fabio', 'cachorro', 34, '0', 'teste', 'e0b9709c0035e4b0ff31bae3ae577c5e.jpg', 0, 'img_qrcode/e0b9709c0035e4b0ff31bae3ae577c5e.png'),
(32, 'fabio', 'cachorro', 34, '0', 'teste', '9ca0781e78155f1a95f6fbc4fd2c3c7b.jpg', 0, 'img_qrcode/d2de4495c26b028ab35697e217128291.png'),
(33, 'fabio', 'cachorro', 34, '0', 'teste', '2c4ae19247c2f0c501a09896448d08c7.jpg', 0, 'img_qrcode/2c4ae19247c2f0c501a09896448d08c7.png'),
(34, 'fabio', 'cachorro', 34, '0', 'teste', '50007a72dd4e83870ea51c837e2a761c.jpg', 0, 'img_qrcode/50007a72dd4e83870ea51c837e2a761c.png'),
(35, 'fabio', 'cachorro', 34, '0', 'teste', '952d5b6a9fc606f80f1dcd1dc224f261.jpg', 0, 'img_qrcode/952d5b6a9fc606f80f1dcd1dc224f261.png'),
(36, 'fabio', 'cachorro', 34, '0', 'teste', 'a4d969fce48e03cf1b55ed665a481bb1.jpg', 0, 'img_qrcode/a4d969fce48e03cf1b55ed665a481bb1.png'),
(37, 'fabio', 'cachorro', 34, '0', 'teste', '9c36b8d40514d0ca01845c49f51db41c.jpg', 0, 'img_qrcode/9c36b8d40514d0ca01845c49f51db41c.png'),
(38, 'fabio', 'cachorro', 34, '0', 'teste', '21e8a806ad2c85a0669b7ac41d2ca59f.jpg', 0, 'img_qrcode/21e8a806ad2c85a0669b7ac41d2ca59f.png'),
(39, 'fabio', 'cachorro', 34, '0', 'teste', '9df0df04ffc6a5be1b5705d705e7bc33.jpg', 0, 'img_qrcode/9df0df04ffc6a5be1b5705d705e7bc33.png'),
(40, 'fabio', 'cachorro', 34, '0', 'teste', '668811643b0862af2e176101d1a5de0f.jpg', 0, 'img_qrcode/668811643b0862af2e176101d1a5de0f.png'),
(41, 'fabio', 'cachorro', 34, '0', 'teste', '6c610a89ded1abcd472ae53d62bb715a.jpg', 0, 'img_qrcode/6c610a89ded1abcd472ae53d62bb715a.png'),
(42, 'fabio', 'cachorro', 34, '0', 'teste', '858a9b8e9594fb309199a6bf9c22110e.jpg', 0, 'img_qrcode/858a9b8e9594fb309199a6bf9c22110e.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tab_dono`
--
ALTER TABLE `tab_dono`
  ADD PRIMARY KEY (`id_dono`);

--
-- Indexes for table `tab_pet`
--
ALTER TABLE `tab_pet`
  ADD PRIMARY KEY (`id_pet`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tab_dono`
--
ALTER TABLE `tab_dono`
  MODIFY `id_dono` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tab_pet`
--
ALTER TABLE `tab_pet`
  MODIFY `id_pet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
