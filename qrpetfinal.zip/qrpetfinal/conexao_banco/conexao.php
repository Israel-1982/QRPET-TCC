<!-- Classe para poder concetar com o banco de dados --> 
<?php
	//informações do banco de dados
	$servidor="localhost";
	$banco="qrpet";
	$usuario="root";
	$senha="";

	//As declarações try...catch marcam um bloco de declarações para testar (try), e especifica uma resposta, caso uma exceção seja lançada.
	try{

	//Método PDO para conectar com o banco de dados 
	$conexao = new PDO("mysql:host=$servidor;
		dbname=$banco",
		$usuario,
		$senha);

		//echo '<p>' . 'Conexão Realizada com sucesso!!!'. '</p>';
		return $conexao;
	}catch(PDOException $e){
	//Caso dê erro,retornar o erro
		echo '<p>' . $e->getMessage(). '</p>';
	}

?>